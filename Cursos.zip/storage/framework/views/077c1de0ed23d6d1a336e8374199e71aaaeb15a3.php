
                        <div class="mb-4">
                                <?php echo Form::label('title', 'Titulo del curso'); ?>

                                <?php echo Form::text('title', null, ['class' => 'form-input block w-full mt-2' . ($errors->has('title') ? ' border-red-600' : '')]); ?>


                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-xs text-red-600"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-4">
                                <?php echo Form::label('slug', 'Url del curso'); ?>

                                <?php echo Form::text('slug', null, ['readonly'=> 'readonly', 'class' => 'form-input block w-full mt-2 ' . ($errors->has('slug') ? ' border-red-600 ' : '')]); ?>


                                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-xs text-red-600"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-4">
                                <?php echo Form::label('subtitle', 'Subtitulo del curso'); ?>

                                <?php echo Form::text('subtitle', null, ['class' => 'form-input block w-full mt-2' . ($errors->has('subtitle') ? ' border-red-600' : '')]); ?>


                                <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-xs text-red-600"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-4">
                                <?php echo Form::label('description', 'Descripcion del curso'); ?>

                                <?php echo Form::textarea('description', null, ['class' => 'form-input block  w-full mt-2']); ?>


                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-xs text-red-600"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="grid grid-cols-3 gap-4">
                            <div>
                                <?php echo Form::label('category_id', 'Categoria:'); ?>

                                <?php echo Form::select('category_id', $categorias, null, ['class' => 'form-input block  w-full mt-2']); ?>

                            </div>

                            <div>
                                <?php echo Form::label('level_id', 'Grados académico:'); ?>

                                <?php echo Form::select('level_id', $niveles, null, ['class' => 'form-input block  w-full mt-2']); ?>

                            </div>

                            <div>
                                <?php echo Form::label('price_id', 'Precio:'); ?>

                                <?php echo Form::select('price_id', $precios, null, ['class' => 'form-input block  w-full mt-2']); ?>

                            </div>
                        </div>

                        <h1 class="text-2xl font-bold mt-8 mb-2">Imagen del curso</h1>

                        <div class="grid grid-cols-2 gap-4">
                            <figure>
                                <?php if(isset($course->image)): ?>
                                    <img id="picture" class="w-full h-70 object-cover object-center" src="<?php echo e(asset('/storage/'.$course->image->url)); ?>" alt="">
                                <?php else: ?>
                                    <img id="picture" class="w-full h-64 object-cover object-center" src="https://images.pexels.com/photos/6368912/pexels-photo-6368912.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" alt="">
                                <?php endif; ?>
                            </figure>

                            <div>
                                <p class="mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab beatae sunt nihil ronem ullamimus, expedita eligendi.</p>
                                <?php echo Form::file('file', ['class' =>'form-input w-full' . ($errors->has('file') ? ' border-red-600' : ''), 'id' => 'file', 'accept'=>'image/*']); ?>

                                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-xs text-red-600"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
<?php /**PATH C:\Users\unive\Desktop\Proyecto\Cursos\resources\views/instructor/courses/partials/form.blade.php ENDPATH**/ ?>