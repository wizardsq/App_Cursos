<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
    <section class="bg-cover" style="background-image: url(<?php echo e(asset('img/cursos/portada_cursos.jpg')); ?>)">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-36">
            <div class="w-full md:w-3/4 lg:w-1/2">
                <h1 class="text-black font-bold text-4xl">Codifica tu futuro</h1>
                <p class="text-black text-lg mt-2 mb-4">Toma las riendas de tu carrera profesional. Aprende las habilidades más actuales</p>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search')->html();
} elseif ($_instance->childHasBeenRendered('TFrkOZE')) {
    $componentId = $_instance->getRenderedChildComponentId('TFrkOZE');
    $componentTag = $_instance->getRenderedChildComponentTagName('TFrkOZE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TFrkOZE');
} else {
    $response = \Livewire\Livewire::mount('search');
    $html = $response->html();
    $_instance->logRenderedChild('TFrkOZE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </section>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('courses-index')->html();
} elseif ($_instance->childHasBeenRendered('4uu2TPe')) {
    $componentId = $_instance->getRenderedChildComponentId('4uu2TPe');
    $componentTag = $_instance->getRenderedChildComponentTagName('4uu2TPe');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4uu2TPe');
} else {
    $response = \Livewire\Livewire::mount('courses-index');
    $html = $response->html();
    $_instance->logRenderedChild('4uu2TPe', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\unive\Desktop\Proyecto\Cursos\resources\views/course/index.blade.php ENDPATH**/ ?>