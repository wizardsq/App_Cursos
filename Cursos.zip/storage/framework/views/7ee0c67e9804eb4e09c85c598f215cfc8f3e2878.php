

<?php $__env->startSection('title', 'CURSOS FITEC'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar nivel</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('info')): ?>

    <div class="alert alert-success">
        <?php echo e(session('info')); ?>

    </div>

    <?php endif; ?>
        <?php echo Form::model($level,['route' => ['admin.levels.update', $level], 'method' => 'PUT']); ?>

        <div class="form-group">
            <?php echo Form::label('name', 'Nombre'); ?>

            <?php echo Form::text('name', null, ['class'=> 'form-control', 'placeholder'=> 'Ingrese el nombre del nivel']); ?>

            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger text-sm"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <?php echo Form::submit('Actualizar Nivel',['class'=> 'btn btn-primary']); ?>

        <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\unive\Desktop\Proyecto\Cursos\resources\views/admin/levels/edit.blade.php ENDPATH**/ ?>