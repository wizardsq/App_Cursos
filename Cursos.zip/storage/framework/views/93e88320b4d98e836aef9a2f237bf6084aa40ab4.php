<?php $attributes = $attributes->exceptProps(['curso']); ?>
<?php foreach (array_filter((['curso']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<article class="card flex flex-col">
    <img class="h-36 w-full object-cover" src="<?php echo e(asset('/storage/'.$curso->image->url)); ?>" alt="">
    <div class="card-body flex-1 flex flex-col">
         <h1 class="card-title"><?php echo e(Str::limit($curso->title, 40)); ?></h1>
         <p class="text-gray-500 text-sm mb-2 mt-auto">Prof: <?php echo e($curso->teacher->name); ?></p>
         <div class="flex">
         <ul class="flex text-sm">
             <li class="mr-1">
                 <i class="fas fa-star text-<?php echo e($curso->rating >=1 ? 'yellow' : 'gray'); ?>-400"></i>
             </li>
             <li class="mr-1">
                 <i class="fas fa-star text-<?php echo e($curso->rating >=2 ? 'yellow' : 'gray'); ?>-400"></i>
             </li>
             <li class="mr-1">
                 <i class="fas fa-star text-<?php echo e($curso->rating >=3 ? 'yellow' : 'gray'); ?>-400"></i>
             </li>
             <li class="mr-1">
                 <i class="fas fa-star text-<?php echo e($curso->rating >=4 ? 'yellow' : 'gray'); ?>-400"></i>
             </li>
             <li class="mr-1">
                 <i class="fas fa-star text-<?php echo e($curso->rating >=5 ? 'yellow' : 'gray'); ?>-400"></i>
             </li>
         </ul>
             <p class="text-sm text-gray-500 ml-auto">
                 <i class="fas fa-users"></i>
                 (<?php echo e($curso->students_count); ?>)
             </p>
         </div>

         <?php if($curso->price->value == 0): ?>
            <p class="my-2 text-green-800 font-bold">Gratis</p>
         <?php else: ?>
            <p class="my-2 text-gray-500 font-bold">US$ <?php echo e($curso->price->value); ?></p>
         <?php endif; ?> 

         <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('enrolled', $curso)): ?>
            <a href="<?php echo e(route('courses.show', $curso)); ?>" class="btn-block btn btn-primary">
                Continuar con el curso
            </a>
         <?php else: ?>
            <a href="<?php echo e(route('courses.show', $curso)); ?>" class="btn-block btn btn-primary">
                Mas informacion
            </a>
        <?php endif; ?>

        
    </div>
 </article><?php /**PATH C:\Users\unive\Desktop\Proyecto\Cursos\resources\views/components/course-card.blade.php ENDPATH**/ ?>