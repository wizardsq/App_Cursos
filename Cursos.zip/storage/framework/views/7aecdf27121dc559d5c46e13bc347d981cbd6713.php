<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>">

        <?php echo \Livewire\Livewire::styles(); ?>


        <!-- Scripts -->
        <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation-dropdown')->html();
} elseif ($_instance->childHasBeenRendered('Zcilp0H')) {
    $componentId = $_instance->getRenderedChildComponentId('Zcilp0H');
    $componentTag = $_instance->getRenderedChildComponentTagName('Zcilp0H');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Zcilp0H');
} else {
    $response = \Livewire\Livewire::mount('navigation-dropdown');
    $html = $response->html();
    $_instance->logRenderedChild('Zcilp0H', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <!-- Page Content -->
            <div class="container py-8 grid grid-cols-5 gap-6">

                <aside>
                    <h1 class="font-bold text-lg mb-3">Edicion del curso</h1>
                        <ul class="text-sm text-gray-700 mb-4">
                            <li class="leading-7 mb-1 border-l-4 <?php if(Request::url() == route('instructor.courses.edit',$course)):?> border-indigo-400 <?php else: ?> border-transparent  <?php endif; ?> pl-2">
                                <a href="<?php echo e(route('instructor.courses.edit',$course)); ?>">Informacion</a>
                            </li>
                            <li class="leading-7 mb-1 border-l-4 <?php if(Request::url() == route('instructor.courses.curriculum', $course)):?> border-indigo-400 <?php else: ?> border-transparent  <?php endif; ?> pl-2">
                                <a href="<?php echo e(route('instructor.courses.curriculum', $course)); ?>">Lecciones</a>
                            </li>
                            <li class="leading-7 mb-1 border-l-4 <?php if(Request::url() == route('instructor.courses.goals', $course)):?> border-indigo-400 <?php else: ?> border-transparent  <?php endif; ?> pl-2">
                                <a href="<?php echo e(route('instructor.courses.goals', $course)); ?>">Metas</a>
                            </li>
                            <li class="leading-7 mb-1 border-l-4 <?php if(Request::url() == route('instructor.courses.students', $course)):?> border-indigo-400 <?php else: ?> border-transparent  <?php endif; ?> pl-2">
                                <a href="<?php echo e(route('instructor.courses.students', $course)); ?>">Estudiantes</a>
                            </li>
                        </ul>

                        <?php switch($course->status):
                            case (1): ?>
                                <form action="<?php echo e(route('instructor.courses.status',$course)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-danger">Solicitar Revision</button>
                                </form>
                                <?php break; ?>
                            <?php case (2): ?>
                                    <div class="card text-gray-500">
                                        <div class="card-body">
                                            Este curso se encuentra en Revision
                                        </div>
                                    </div>
                                <?php break; ?>

                            <?php case (3): ?>
                            <div class="card text-gray-500">
                                <div class="card-body">
                                    Este curso se encuentra Publicado
                                </div>
                            </div>
                            <?php break; ?>
                            <?php default: ?>
                                
                        <?php endswitch; ?>

                        

                </aside>
        
                <div class="col-span-4 card">
                    <main class="card-body text-gray-600">
                        <?php echo e($slot); ?>

                    </main>
                </div>
            </div>
        </div>

        <?php echo $__env->yieldPushContent('modals'); ?>

        <?php echo \Livewire\Livewire::scripts(); ?>


        <?php if(isset($js)): ?>

            <?php echo e($js); ?>

            
        <?php endif; ?>
      
    </body>
</html>
<?php /**PATH C:\Users\unive\Desktop\Proyecto\Cursos\resources\views/layouts/instructor.blade.php ENDPATH**/ ?>