<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="card mt-5">
        <div class="card-body">
            <h1 class="text-blue-500 flex justify-center font-bold text-2xl">Aviso de privacidad</h1>
            <section class="mt-2">
                <p class="text-sm text-gray-700">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Non dolorum harum reiciendis quaerat? Sit harum temporibus reprehenderit, nobis quidem accusamus eveniet dolore possimus, totam corporis odio architecto voluptatem sint assumenda.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae, architecto nihil! Hic fugiat harum cumque aspernatur quae. Obcaecati praesentium porro, dolorem soluta vero architecto, voluptatum, similique dolor modi nobis minima.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam tempora earum vitae. Ex odio laudantium temporibus est non exercitationem repudiandae, corporis expedita quam veniam quis praesentium, explicabo, distinctio libero neque?
                </p>
                
            </section>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\unive\Desktop\Proyecto\Cursos\resources\views/aviso/index.blade.php ENDPATH**/ ?>