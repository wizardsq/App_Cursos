<div>
    <?php $__currentLoopData = $section->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="card mt-4" x-data="{open: false}">
            <div class="card-body">

                <?php if($lesson->id == $item->id): ?>
                    <form wire:submit.prevent="update">
                        <div class="flex items-center">
                            <label class="w-32">Nombre:</label>
                            <input wire:model="lesson.name" class="form-input w-full" >
                        </div>
                        <?php $__errorArgs = ['lesson.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="flex items-center mt-4">
                            <label class="w-32">Plataforma: </label>
                            <select class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" wire:model="lesson.platform_id">
                                <?php $__currentLoopData = $platforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($platform->id); ?>"><?php echo e($platform->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="flex items-center mt-4">
                            <label class="w-32">Url:</label>
                            <input wire:model="lesson.url" class="form-input w-full" >
                        </div>
                        <?php $__errorArgs = ['lesson.url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="mt-4 flex justify-end">
                            <button type="button" class="btn btn-danger" wire:click="cancel">Cancelar</button>
                            <button type="submit" class="btn btn-primary ml-2" >Actualizar</button>
                        </div>
                    </form>
                <?php else: ?>
            
                    <header>
                        <h1 class="cursor-pointer" x-on:click="open = !open"><i class="far fa-play-circle text-blue-500 mr-1"></i> Leccion: <?php echo e($item->name); ?></h1>
                    </header>

                    <div x-show="open">
                        <hr class="my-3">
                        <p class="text-sm">Plataforma: <?php echo e($item->platform->name); ?></p>
                        <p class="text-sm">Enlace: <a class="text-blue-600"href="<?php echo e($item->url); ?>" target="_blank"><?php echo e($item->url); ?></a></p>

                        <div class="my-3">
                            <button class="btn btn-primary text-sm" wire:click="edit(<?php echo e($item); ?>)">Editar</button>
                            <button class="btn btn-danger text-sm" wire:click="destroy(<?php echo e($item); ?>)">Eliminar</button>
                        </div>

                        <div>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('instructor.lesson-description', ['lesson' =>$item])->html();
} elseif ($_instance->childHasBeenRendered('lesson-description-' . $item->id)) {
    $componentId = $_instance->getRenderedChildComponentId('lesson-description-' . $item->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('lesson-description-' . $item->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lesson-description-' . $item->id);
} else {
    $response = \Livewire\Livewire::mount('instructor.lesson-description', ['lesson' =>$item]);
    $html = $response->html();
    $_instance->logRenderedChild('lesson-description-' . $item->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>

                        <div>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('instructor.lesson-resource', ['lesson' => $item])->html();
} elseif ($_instance->childHasBeenRendered('lesson-resource-' . $item->id)) {
    $componentId = $_instance->getRenderedChildComponentId('lesson-resource-' . $item->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('lesson-resource-' . $item->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lesson-resource-' . $item->id);
} else {
    $response = \Livewire\Livewire::mount('instructor.lesson-resource', ['lesson' => $item]);
    $html = $response->html();
    $_instance->logRenderedChild('lesson-resource-' . $item->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="mt-4" x-data="{open: false}">
        <a x-show="!open" x-on:click="open = true" class="flex item-center cursor-pointer" >
            <i class="far fa-plus-square text-2xl text-red-500 mr-2"></i>
            Agregar nueva Leccion
        </a>

        <article class="card" x-show="open">
            <div class="card-body ">
                <h1 class="text-xl font-bold">Nueva Leccion</h1>
                    <div>
                        <div class="flex items-center">
                            <label class="w-32">Nombre:</label>
                            <input wire:model="name" class="form-input w-full" >
                        </div>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="flex items-center mt-4">
                            <label class="w-32">Plataforma: </label>
                            <select class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" wire:model="platform_id">
                                <?php $__currentLoopData = $platforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($platform->id); ?>"><?php echo e($platform->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <?php $__errorArgs = ['platform_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                        <div class="flex items-center mt-4">
                            <label class="w-32">Url:</label>
                            <input wire:model="url" class="form-input w-full" >
                        </div>
                        <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="flex justify-end mt-4">
                        <button class="btn btn-danger" x-on:click="open = false">Cancelar</button>
                        <button class="btn btn-primary ml-2" wire:click="store">Agregar</button>
                    </div>
            </div>
        </article>
    </div>
</div>
 <?php /**PATH C:\Users\unive\Desktop\Proyecto\Cursos\resources\views/livewire/instructor/courses-lesson.blade.php ENDPATH**/ ?>