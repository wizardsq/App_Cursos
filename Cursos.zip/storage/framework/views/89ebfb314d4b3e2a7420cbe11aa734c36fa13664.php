<div class="card mt-4" x-data="{open: false}">
    <div class="card-body bg-gray-100">
        <header>
            <h1 class="cursor-pointer" x-on:click="open = !open">Recursos de la leccion</h1>
        </header>

        <div x-show="open">
            <hr class="my-2">

            <?php if($lesson->resource): ?>
                <div class="flex justify-between items-center">
                    <p> <i wire:click="download" class="fas fa-download text-blue-400 mr-2 cursor-pointer"></i> <?php echo e($lesson->resource->url); ?></p>
                    <i wire:click="destroy" class="fas fa-trash text-red-500 cursor-pointer"></i>
                </div>
            <?php else: ?>
                <form wire:submit.prevent="save">
                    <div class="flex items-center">
                        <input wire:model="file" type="file" class="form-input flex-1">
                        <button type="submit" class="btn btn-primary text-sm ml-2">guardar</button>
                    </div>

                    <div class="text-blue-500 font-bold mt-1 ml-1" wire:loading wire:target="file">
                        Cargando..
                    </div>

                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-xs text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </form>

            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\unive\Desktop\Proyecto\Cursos\resources\views/livewire/instructor/lesson-resource.blade.php ENDPATH**/ ?>