<x-app-layout>
    @livewire('instructor.courses-index');
</x-app-layout>